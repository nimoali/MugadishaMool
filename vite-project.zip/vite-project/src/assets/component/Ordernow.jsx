function Ordernow(){
    return (
        <div className="bg-[url('https://img.freepik.com/free-photo/top-view-burger-fries-plate-with-pickles_23-2148784451.jpg?ga=GA1.1.1755721118.1716872895&semt=sph')] p-10 text-center text-white ">
          <h1 className="text-3xl font-bold mb-4">Order Now!</h1>
          <p className="text-lg text-white mb-8">and Get 50% Off</p>
          <p className="text-lg text-white mb-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vitae nisi ut massa hendrerit maximus.</p>
          <button className="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded mr-10">Shop Now</button>
          <button className="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded">Order Now!</button>
        </div>
      );
}

export default Ordernow;