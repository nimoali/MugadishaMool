import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './assets/pages/Home';

// import About from './pages/About';
// import Contact from './pages/Contact';

const App = () => {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <nav className="bg-gray-800 p-4 text-white">
          <div className="container mx-auto flex justify-between">
            <Link to="/" className="font-bold">Home</Link>
            {/* <Link to="/about" className="font-bold">About</Link>
            <Link to="/contact" className="font-bold">Contact</Link> */}
          </div>
        </nav>
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            {/* <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} /> */}
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
